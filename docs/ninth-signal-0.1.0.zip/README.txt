THE NINTH SIGNAL — free prototype 0.1.0
A short fictional evidence mystery at Bracken Station.

Extract this ZIP, then open index.html in a modern browser. No installation,
account, internet connection or payment is needed. Open all six records,
compare their timestamps, then choose a dispatch. All three outcomes are
explained, and you can return to the records. There is no real-time timer.
Keyboard: Tab moves between controls; Enter activates buttons and records.
Progress lasts only while the page is open; reloading starts again.

Contains fictional peril during an evacuation, without graphic violence.
This is entertainment, not emergency-response advice or training.
AI-assisted writing and code. No external images, music or libraries.
No analytics or data collection. No open-source or redistribution license
is granted with this prototype. Free to play for personal evaluation.

Verified in local Microsoft Edge on Windows at 390px and desktop widths.
Other browsers and assistive technology have not yet been verified.
Feedback questions: Could you finish without help? Which record clarified
or confused your decision? Would you choose to play another original case?
Do not send personal information. A public feedback route will accompany
publication; this local package does not transmit feedback.
